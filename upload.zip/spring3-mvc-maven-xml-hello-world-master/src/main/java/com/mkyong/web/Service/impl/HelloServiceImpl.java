package com.mkyong.web.Service.impl;

import org.springframework.stereotype.Service;

@Service("HelloService")

public class HelloServiceImpl {

}
