package com.mkyong.web.Dao;

import org.springframework.stereotype.Repository;

@Repository("HelloDao")

public class HelloDao {

}
