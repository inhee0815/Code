package com.mkyong.web.Service;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.mkyong.web.util.ExcelRead;
import com.mkyong.web.util.ExcelReadOption;

@Service
public class HelloService {

	public void excelUpload(File destFile) throws Exception {
        ExcelReadOption excelReadOption = new ExcelReadOption();
        excelReadOption.setFilePath(destFile.getAbsolutePath());
        excelReadOption.setOutputColumns("A");
        excelReadOption.setStartRow(1);
        
        List<Map<String, String>> excelContent =ExcelRead.read(excelReadOption);
        
        Connection con = null;
        int i=100;
        try {
        	con = getConnection();
        	String sql = "INSERT INTO tb_member_info VALUES (?,?,?)"; 
        	PreparedStatement pstmt = con.prepareStatement(sql); 
        
        	for(Map<String, String> article: excelContent){
        		System.out.println(article.get("A"));
        		pstmt.setString(1, "������"+(i++)); 
        		pstmt.setString(2, "member_code"); 
        		pstmt.setString(3, article.get("A")); 
        		pstmt.executeUpdate(); 
        	}
        } catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

        
	}

	public static Connection getConnection() throws Exception {

		try {
			String driver = "com.mysql.jdbc.Driver";
			String url = "jdbc:mysql://localhost:3306/test";
			String username = "root";
			String password = "rladlsgml!";
			Class.forName(driver);

			Connection conn = DriverManager.getConnection(url, username, password);
			System.out.println("Connected");
			return conn;

		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}
}
