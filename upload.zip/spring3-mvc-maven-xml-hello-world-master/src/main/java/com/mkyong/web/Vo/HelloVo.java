package com.mkyong.web.Vo;

public class HelloVo {

}
